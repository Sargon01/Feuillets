import test from "node:test";
import assert from "node:assert/strict";
import { TFile, TFolder } from "obsidian";
import { createFakeVault } from "./helpers/fake-vault.js";
import {
  ensureTemplateFile,
  loadCustomTemplates,
  duplicateExportTemplate,
  listExportTemplates,
  resolveExportTemplate,
  loadCustomTemplatesV2,
  resolveExportTemplateV2,
  saveExportTemplateV2,
  customTemplateFile,
  renameCustomTemplate,
  deleteCustomTemplate,
  exportBuiltInTemplates,
} from "../src/services/export-templates-custom.js";
import { EXPORT_TEMPLATES } from "../src/utils/export-templates.js";
import { normalizeLegacyTemplate } from "../src/services/export-template-v2.js";

test("export templates custom : lit un modèle et crée un modèle manquant", async () => {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  const resources = new TFolder("Projet/Resources");
  const layouts = new TFolder("Projet/Resources/Layouts");
  const custom = new TFile("Projet/Resources/Layouts/perso.md");
  manuscript.parent = project; resources.parent = project; layouts.parent = resources; custom.parent = layouts;
  project.children = [manuscript, resources]; resources.children = [layouts]; layouts.children = [custom];
  const { vault, fileManager } = createFakeVault([project, manuscript, resources, layouts, custom]);
  const app = { vault, fileManager, metadataCache: { getFileCache: (file) => ({ frontmatter: file === custom ? { label: "Mon modèle", fontSizePt: 11 } : {} }) } };
  const settings = { projectFolder: manuscript.path };

  const templates = await loadCustomTemplates(app, settings);
  const created = await ensureTemplateFile(app, settings, "classique");

  assert.equal(templates.perso.label, "Mon modèle");
  assert.equal(created?.path, "Projet/Resources/Layouts/classique.md");
});

test("export templates custom V2 : la sauvegarde matérialise un builtin complet sans champs legacy ni réglages pdf", async () => {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  manuscript.parent = project; project.children = [manuscript];
  const { vault, fileManager } = createFakeVault([project, manuscript]);
  const writes = [];
  fileManager.processFrontMatter = async (file, update) => {
    const fm = { indent: true, pdfHeaderLeft: "Ancien", pageNumbers: true };
    update(fm);
    writes.push({ file, fm });
  };
  const app = { vault, fileManager, metadataCache: { getFileCache: () => ({ frontmatter: {} }) } };
  const settings = { projectFolder: manuscript.path, exportTemplate: "classique", pdfHeaderLeft: "Global inchangé" };
  const template = normalizeLegacyTemplate(EXPORT_TEMPLATES.classique);
  template.profile = "manuscript";
  template.page.marginsCm.left = 3.2;
  template.body.firstLineIndentPt = 24;
  template.headings.h6 = { fontSizePt: 9, italic: true };
  template.header.center = "{page}";
  template.footer.right = "{page}";
  template.titlePage.styles = { titre: { fontSizePt: 22, bold: true } };

  await saveExportTemplateV2(app, settings, "classique", template);

  const saved = writes[0].fm;
  assert.equal(saved.version, 2);
  assert.equal(saved.profile, "manuscript");
  assert.equal(saved.page.marginsCm.left, 3.2);
  assert.equal(saved.body.firstLineIndentPt, 24);
  assert.deepEqual(saved.headings.h6, { fontSizePt: 9, italic: true });
  assert.equal(saved.header.center, "{page}");
  assert.equal(saved.footer.right, "{page}");
  assert.deepEqual(saved.titlePage.styles.titre, { fontSizePt: 22, bold: true });
  for (const key of ["indent", "pdfHeaderLeft", "pageNumbers", "pageNumberPosition", "chapterTitle"]) assert.equal(key in saved, false);
  assert.equal(settings.pdfHeaderLeft, "Global inchangé");
});

test("semanticRoleMarkers : sauvegardé puis relu via loadCustomTemplates (round-trip \"show\")", async () => {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  manuscript.parent = project; project.children = [manuscript];
  const { vault, fileManager } = createFakeVault([project, manuscript]);
  let savedFrontmatter = null;
  fileManager.processFrontMatter = async (file, update) => {
    const fm = {};
    update(fm);
    savedFrontmatter = fm;
  };
  const app = { vault, fileManager, metadataCache: { getFileCache: () => ({ frontmatter: savedFrontmatter || {} }) } };
  const settings = { projectFolder: manuscript.path, exportTemplate: "classique" };
  const template = normalizeLegacyTemplate(EXPORT_TEMPLATES.classique);
  template.semanticRoleMarkers = "show";

  await saveExportTemplateV2(app, settings, "classique", template);

  assert.equal(savedFrontmatter.semanticRoleMarkers, "show");
  const custom = await loadCustomTemplates(app, settings);
  assert.equal(custom.classique.semanticRoleMarkers, "show");
});

/* ---------------------- couleur du corps / titres, soulignement ---------- */

test("body.colorHex / heading.colorHex / heading.underline : sauvegardés puis relus à l'identique (V2 et projection legacy)", async () => {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  manuscript.parent = project; project.children = [manuscript];
  const { vault, fileManager } = createFakeVault([project, manuscript]);
  let savedFrontmatter = null;
  fileManager.processFrontMatter = async (file, update) => {
    const fm = {};
    update(fm);
    savedFrontmatter = fm;
  };
  const app = { vault, fileManager, metadataCache: { getFileCache: () => ({ frontmatter: savedFrontmatter || {} }) } };
  const settings = { projectFolder: manuscript.path, exportTemplate: "classique" };
  const template = normalizeLegacyTemplate(EXPORT_TEMPLATES.classique);
  template.body.colorHex = "#223344";
  template.headings.h1.colorHex = "#AA1122";
  template.headings.h1.underline = true;
  template.headings.h6.colorHex = "#334455";
  template.headings.h6.underline = false;

  await saveExportTemplateV2(app, settings, "classique", template);

  // V2 : round-trip exact.
  const reloadedV2 = await resolveExportTemplateV2(app, settings, "classique");
  assert.equal(reloadedV2.body.colorHex, "#223344");
  assert.equal(reloadedV2.headings.h1.colorHex, "#AA1122");
  assert.equal(reloadedV2.headings.h1.underline, true);
  assert.equal(reloadedV2.headings.h6.colorHex, "#334455");
  assert.equal(reloadedV2.headings.h6.underline, false);
  assert.equal(reloadedV2.headings.h2.colorHex, undefined);

  // Projection legacy (consommée par templateToCss) : mêmes valeurs.
  const reloadedLegacy = await loadCustomTemplates(app, settings);
  assert.equal(reloadedLegacy.classique.colorHex, "#223344");
  assert.equal(reloadedLegacy.classique.headings.h1.colorHex, "#AA1122");
  assert.equal(reloadedLegacy.classique.headings.h1.underline, true);
  assert.equal(reloadedLegacy.classique.headings.h6.colorHex, "#334455");
  assert.equal(reloadedLegacy.classique.headings.h6.underline, false);
});

test("body.colorHex / heading.colorHex absents : round-trip conserve leur absence (repli historique)", async () => {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  manuscript.parent = project; project.children = [manuscript];
  const { vault, fileManager } = createFakeVault([project, manuscript]);
  let savedFrontmatter = null;
  fileManager.processFrontMatter = async (file, update) => {
    const fm = {};
    update(fm);
    savedFrontmatter = fm;
  };
  const app = { vault, fileManager, metadataCache: { getFileCache: () => ({ frontmatter: savedFrontmatter || {} }) } };
  const settings = { projectFolder: manuscript.path, exportTemplate: "classique" };
  const template = normalizeLegacyTemplate(EXPORT_TEMPLATES.classique);

  await saveExportTemplateV2(app, settings, "classique", template);

  const reloadedV2 = await resolveExportTemplateV2(app, settings, "classique");
  assert.equal(reloadedV2.body.colorHex, undefined);
  assert.equal(reloadedV2.headings.h1.colorHex, undefined);
  assert.equal(reloadedV2.headings.h1.underline, undefined);
  const reloadedLegacy = await loadCustomTemplates(app, settings);
  assert.equal(reloadedLegacy.classique.colorHex, undefined);
});

test("duplicateExportTemplate : conserve body.colorHex, heading.colorHex et heading.underline du gabarit dupliqué", async () => {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  manuscript.parent = project; project.children = [manuscript];
  const { vault, fileManager } = createFakeVault([project, manuscript]);
  let savedFrontmatter = null;
  fileManager.processFrontMatter = async (file, update) => {
    const fm = {};
    update(fm);
    savedFrontmatter = fm;
  };
  const app = { vault, fileManager, metadataCache: { getFileCache: () => ({ frontmatter: savedFrontmatter || {} }) } };
  const settings = { projectFolder: manuscript.path, exportTemplate: "classique" };
  const template = normalizeLegacyTemplate(EXPORT_TEMPLATES.classique);
  template.body.colorHex = "#223344";
  template.headings.h2.colorHex = "#654321";
  template.headings.h2.underline = true;
  await saveExportTemplateV2(app, settings, "classique", template);

  const result = await duplicateExportTemplate(app, settings);
  const reloadedV2 = await resolveExportTemplateV2(app, settings, result.key);

  assert.equal(reloadedV2.body.colorHex, "#223344");
  assert.equal(reloadedV2.headings.h2.colorHex, "#654321");
  assert.equal(reloadedV2.headings.h2.underline, true);
});

test("semanticRoleMarkers : un ancien gabarit sans le champ reste \"legacy\" (aucune migration destructive)", async () => {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  const resources = new TFolder("Projet/Resources");
  const layouts = new TFolder("Projet/Resources/Layouts");
  const old = new TFile("Projet/Resources/Layouts/ancien.md");
  manuscript.parent = project; resources.parent = project; layouts.parent = resources; old.parent = layouts;
  project.children = [manuscript, resources]; resources.children = [layouts]; layouts.children = [old];
  const { vault, fileManager } = createFakeVault([project, manuscript, resources, layouts, old]);
  const oldFrontmatter = {
    version: 2, profile: "document",
    page: { size: "A4", orientation: "portrait", marginsCm: { top: 2, bottom: 2, left: 2, right: 2 }, mirrorMargins: false, columns: { count: 1, gutterPt: 0 } },
    body: { fontFamily: "Georgia", fontSizePt: 12, lineHeight: 1.5, align: "left", firstLineIndentPt: 0, paragraphSpacingBeforePt: 0, paragraphSpacingAfterPt: 0, hyphenation: false },
    headings: { h1: {}, h2: {}, h3: {}, h4: {}, h5: {}, h6: {} },
    blockquote: {}, sceneDivider: "",
    header: { enabled: true, left: "", center: "", right: "", distanceCm: 0.75, bodyGapPt: 3, differentOddEven: false },
    footer: { enabled: true, left: "", center: "", right: "", distanceCm: 0.75, bodyGapPt: 3 },
    firstPage: { hideHeader: true, pageNumberPosition: "right" },
    titlePage: { styles: {} },
    // pas de semanticRoleMarkers : fichier écrit avant ce lot.
  };
  const app = { vault, fileManager, metadataCache: { getFileCache: (file) => ({ frontmatter: file === old ? oldFrontmatter : {} }) } };
  const settings = { projectFolder: manuscript.path };

  const custom = await loadCustomTemplates(app, settings);

  assert.equal(custom.ancien.semanticRoleMarkers, "legacy");
});

test("export templates custom : un nouveau projet sans dossier existant crée dans Mises en page (nom canonique)", async () => {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  manuscript.parent = project;
  project.children = [manuscript];
  const { vault, fileManager } = createFakeVault([project, manuscript]);
  const app = { vault, fileManager, metadataCache: { getFileCache: () => ({ frontmatter: {} }) } };
  const settings = { projectFolder: manuscript.path };

  const created = await ensureTemplateFile(app, settings, "classique");

  assert.equal(created?.path, "Projet/_Feuillets/Ressources/Mises en page/classique.md");
});

test("export templates custom : conserve les valeurs valides et ignore les valeurs de police invalides", async () => {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  const resources = new TFolder("Projet/Resources");
  const layouts = new TFolder("Projet/Resources/Layouts");
  const valid = new TFile("Projet/Resources/Layouts/valide.md");
  const invalid = new TFile("Projet/Resources/Layouts/invalide.md");
  manuscript.parent = project; resources.parent = project; layouts.parent = resources;
  valid.parent = layouts; invalid.parent = layouts;
  project.children = [manuscript, resources]; resources.children = [layouts]; layouts.children = [valid, invalid];
  const frontmatter = new Map([
    [valid, { fontFamily: "Georgia, serif", fontSizePt: 11, lineHeight: 1.5 }],
    [invalid, { fontFamily: "  ", fontSizePt: 0, lineHeight: null }],
  ]);
  const { vault, fileManager } = createFakeVault([project, manuscript, resources, layouts, valid, invalid]);
  const app = { vault, fileManager, metadataCache: { getFileCache: (file) => ({ frontmatter: frontmatter.get(file) ?? {} }) } };
  const settings = { projectFolder: manuscript.path };

  const templates = await loadCustomTemplates(app, settings);

  assert.equal(templates.valide.fontFamily, "Georgia, serif");
  assert.equal(templates.valide.fontSizePt, 11);
  assert.equal(templates.valide.lineHeight, 1.5);
  assert.equal(templates.invalide.fontFamily, EXPORT_TEMPLATES.classique.fontFamily);
  assert.equal(templates.invalide.fontSizePt, EXPORT_TEMPLATES.classique.fontSizePt);
  assert.equal(templates.invalide.lineHeight, EXPORT_TEMPLATES.classique.lineHeight);
});

test("export templates custom : un gabarit personnalisé de même clé est résolu avant l'intégré", async () => {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  const resources = new TFolder("Projet/Resources");
  const layouts = new TFolder("Projet/Resources/Layouts");
  const customApa = new TFile("Projet/Resources/Layouts/apa.md");
  manuscript.parent = project; resources.parent = project; layouts.parent = resources; customApa.parent = layouts;
  project.children = [manuscript, resources]; resources.children = [layouts]; layouts.children = [customApa];
  const { vault, fileManager } = createFakeVault([project, manuscript, resources, layouts, customApa]);
  const app = {
    vault,
    fileManager,
    metadataCache: { getFileCache: (file) => ({ frontmatter: file === customApa ? { label: "APA maison", fontSizePt: 13, hyphenation: true } : {} }) },
  };

  const resolved = await resolveExportTemplate(app, { projectFolder: manuscript.path }, "apa");

  assert.equal(resolved.key, "apa");
  assert.equal(resolved.label, "APA maison");
  assert.equal(resolved.fontSizePt, 13);
  assert.equal(resolved.hyphenation, true);
  assert.equal(resolved.custom, true);
  assert.equal(resolved.fontFamily, EXPORT_TEMPLATES.classique.fontFamily, "le personnalisé conserve sa résolution actuelle depuis Classique");
  assert.notEqual(resolved, EXPORT_TEMPLATES.apa);
});

test("export templates custom V2 : un ancien fichier reste lisible sans fusion implicite avec Classique", async () => {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  const resources = new TFolder("Projet/Resources");
  const layouts = new TFolder("Projet/Resources/Layouts");
  const custom = new TFile("Projet/Resources/Layouts/ancien.md");
  manuscript.parent = project; resources.parent = project; layouts.parent = resources; custom.parent = layouts;
  project.children = [manuscript, resources]; resources.children = [layouts]; layouts.children = [custom];
  const frontmatter = { label: "Ancien", fontFamily: "Georgia, serif", fontSizePt: 11, hyphenation: false };
  const { vault, fileManager } = createFakeVault([project, manuscript, resources, layouts, custom]);
  const app = { vault, fileManager, metadataCache: { getFileCache: () => ({ frontmatter }) } };
  const settings = { projectFolder: manuscript.path };

  const legacy = await loadCustomTemplates(app, settings);
  const v2 = await loadCustomTemplatesV2(app, settings);

  assert.equal(legacy.ancien.fontFamily, "Georgia, serif", "la voie legacy conserve sa compatibilité publique");
  assert.equal(v2.ancien.body.fontFamily, "Georgia, serif");
  assert.deepEqual(v2.ancien.headings, {
    h1: { pageBreakBefore: true }, h2: { pageBreakBefore: true }, h3: {}, h4: {}, h5: {}, h6: {},
  }, "V2 ne récupère jamais les titres de Classique");
  assert.equal(v2.ancien.profile, "document");
  assert.deepEqual(frontmatter, { label: "Ancien", fontFamily: "Georgia, serif", fontSizePt: 11, hyphenation: false });
});

test("export templates custom V2 : le profil document est projeté vers la voie legacy", async () => {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  const resources = new TFolder("Projet/Resources");
  const layouts = new TFolder("Projet/Resources/Layouts");
  const custom = new TFile("Projet/Resources/Layouts/document.md");
  manuscript.parent = project; resources.parent = project; layouts.parent = resources; custom.parent = layouts;
  project.children = [manuscript, resources]; resources.children = [layouts]; layouts.children = [custom];
  const frontmatter = {
    version: 2, profile: "document",
    page: { size: "A4", orientation: "portrait", marginsCm: { top: 2.5, bottom: 2.5, left: 2.5, right: 2.5 }, mirrorMargins: false, columns: { count: 1, gutterPt: 0 } },
    body: { fontFamily: "Georgia", fontSizePt: 12, lineHeight: 1.5, align: "left", firstLineIndentPt: 0, paragraphSpacingBeforePt: 0, paragraphSpacingAfterPt: 0, hyphenation: false },
  };
  const { vault, fileManager } = createFakeVault([project, manuscript, resources, layouts, custom]);
  const app = { vault, fileManager, metadataCache: { getFileCache: () => ({ frontmatter }) } };
  const settings = { projectFolder: manuscript.path };

  const resolved = await resolveExportTemplate(app, settings, "document");
  const legacy = await resolveExportTemplate(app, settings, "classique");

  assert.equal(resolved.profile, "document");
  assert.equal(legacy.profile, undefined);
});

/* ---------------------- duplicateExportTemplate (Phase 11) --------------- */

/** Le stub `stringifyYaml` de test/obsidian-runtime-stub.mjs sérialise
 * naïvement (`${key}: ${String(item)}`, sans repli objet imbriqué) : pour
 * relire un frontmatter fraîchement écrit par le service (plutôt que
 * pré-posé à la main comme les fixtures ci-dessus), on relit les champs
 * PLATS du contenu réel du fichier — suffisant pour label/fontFamily, les
 * champs imbriqués (marginsCm, headings…) restent hors de portée de ce
 * mini-parseur, comme du stub lui-même. */
function parseFlatFrontmatter(content) {
  const match = (content || "").match(/^---\n([\s\S]*?)\n---/);
  const out = {};
  if (!match) return out;
  for (const line of match[1].split("\n")) {
    const i = line.indexOf(":");
    if (i === -1) continue;
    const value = line.slice(i + 1).trim();
    if (value === "[object Object]") continue;
    out[line.slice(0, i).trim()] = value;
  }
  return out;
}

function buildFixture() {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  manuscript.parent = project;
  project.children = [manuscript];
  const { vault, fileManager } = createFakeVault([project, manuscript]);
  const app = {
    vault,
    fileManager,
    metadataCache: { getFileCache: (file) => ({ frontmatter: parseFlatFrontmatter(file.content) }) },
  };
  const settings = { projectFolder: manuscript.path, exportTemplate: "classique" };
  return { app, settings };
}

test("duplicateExportTemplate : résout le gabarit actif, crée une copie avec le libellé « <nom> — copie »", async () => {
  const { app, settings } = buildFixture();

  const result = await duplicateExportTemplate(app, settings);

  assert.ok(result);
  assert.equal(result.key, "classique-copie");
  assert.equal(result.label, `${EXPORT_TEMPLATES.classique.label} — copie`);
  const file = app.vault.getAbstractFileByPath("Projet/_Feuillets/Ressources/Mises en page/classique-copie.md");
  assert.ok(file instanceof TFile);
});

test("duplicateExportTemplate : rend IMMÉDIATEMENT la copie active", async () => {
  const { app, settings } = buildFixture();

  const result = await duplicateExportTemplate(app, settings);

  assert.equal(settings.exportTemplate, result.key);
});

test("duplicateExportTemplate : ne remplace jamais un fichier existant — clé unique à chaque appel", async () => {
  const { app, settings } = buildFixture();

  const first = await duplicateExportTemplate(app, settings);
  // Redevient "classique" pour dupliquer deux fois le même gabarit source.
  settings.exportTemplate = "classique";
  const second = await duplicateExportTemplate(app, settings);

  assert.notEqual(first.key, second.key);
  assert.equal(first.key, "classique-copie");
  assert.equal(second.key, "classique-copie-2");
  // Le premier fichier existe toujours, intact.
  assert.ok(app.vault.getAbstractFileByPath("Projet/_Feuillets/Ressources/Mises en page/classique-copie.md") instanceof TFile);
  assert.ok(app.vault.getAbstractFileByPath("Projet/_Feuillets/Ressources/Mises en page/classique-copie-2.md") instanceof TFile);
});

test("duplicateExportTemplate : la copie est immédiatement disponible via listExportTemplates", async () => {
  const { app, settings } = buildFixture();

  const result = await duplicateExportTemplate(app, settings);
  const templates = await listExportTemplates(app, settings);

  assert.ok(templates.some((tpl) => tpl.key === result.key && tpl.label === result.label));
});

test("duplicateExportTemplate : préserve les champs du gabarit dupliqué (pas de valeurs par défaut écrasées)", async () => {
  const { app, settings } = buildFixture();

  const result = await duplicateExportTemplate(app, settings);
  const custom = await loadCustomTemplates(app, settings);

  assert.equal(custom[result.key].fontFamily, EXPORT_TEMPLATES.classique.fontFamily);
  assert.equal(custom[result.key].fontSizePt, EXPORT_TEMPLATES.classique.fontSizePt);
  assert.equal(custom[result.key].lineHeight, EXPORT_TEMPLATES.classique.lineHeight);
});

test("duplicateExportTemplate : écrit une copie V2 de Classique avec le profil manuscript", async () => {
  const { app, settings } = buildFixture();

  const result = await duplicateExportTemplate(app, settings);
  const file = app.vault.getAbstractFileByPath(`Projet/_Feuillets/Ressources/Mises en page/${result.key}.md`);

  assert.match(file.content, /version: 2/);
  assert.match(file.content, /profile: manuscript/);
  for (const field of ["page", "body", "headings", "header", "footer", "firstPage", "titlePage", "blockquote", "sceneDivider"]) {
    assert.match(file.content, new RegExp(`${field}:`), `${field} doit être écrit dans la copie V2`);
  }
});

test("duplicateExportTemplate : conserve le profil document d'un gabarit intégré", async () => {
  const { app, settings } = buildFixture();
  settings.exportTemplate = "romanSimple";

  const result = await duplicateExportTemplate(app, settings);
  const file = app.vault.getAbstractFileByPath(`Projet/_Feuillets/Ressources/Mises en page/${result.key}.md`);

  assert.match(file.content, /profile: document/);
});

test("duplicateExportTemplate : conserve semanticRoleMarkers du gabarit dupliqué", async () => {
  // buildFixture()/parseFlatFrontmatter ne relit que les champs PLATS d'un
  // frontmatter déjà réécrit par la stringification naïve du stub de test
  // (voir le commentaire de parseFlatFrontmatter plus haut) : les champs
  // imbriqués (page/body/…) n'y survivent pas. On simule donc ici un
  // frontmatter SOURCE déjà correctement structuré (comme le ferait la
  // vraie lecture Obsidian) pour isoler le seul comportement testé — la
  // propagation de semanticRoleMarkers par duplicateExportTemplate.
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  const resources = new TFolder("Projet/Resources");
  const layouts = new TFolder("Projet/Resources/Layouts");
  const classiqueFile = new TFile("Projet/Resources/Layouts/classique.md");
  manuscript.parent = project; resources.parent = project; layouts.parent = resources; classiqueFile.parent = layouts;
  project.children = [manuscript, resources]; resources.children = [layouts]; layouts.children = [classiqueFile];
  const { vault, fileManager } = createFakeVault([project, manuscript, resources, layouts, classiqueFile]);
  const sourceFrontmatter = { ...normalizeLegacyTemplate(EXPORT_TEMPLATES.classique), semanticRoleMarkers: "hide", label: EXPORT_TEMPLATES.classique.label };
  const app = { vault, fileManager, metadataCache: { getFileCache: (file) => ({ frontmatter: file === classiqueFile ? sourceFrontmatter : {} }) } };
  const settings = { projectFolder: manuscript.path, exportTemplate: "classique" };

  const result = await duplicateExportTemplate(app, settings);

  assert.ok(result);
  const file = app.vault.getAbstractFileByPath(`Projet/Resources/Layouts/${result.key}.md`);
  assert.match(file.content, /semanticRoleMarkers: hide/);
});

test("resolveExportTemplateV2 : APA et Thèse conservent leur profil académique sans muter les sources", async () => {
  const { app, settings } = buildFixture();
  const before = structuredClone(EXPORT_TEMPLATES);

  const apa = await resolveExportTemplateV2(app, settings, "apa");
  const these = await resolveExportTemplateV2(app, settings, "these");
  apa.page.marginsCm.left = 99;

  assert.equal(apa.profile, "academic");
  assert.equal(these.profile, "academic");
  assert.deepEqual(EXPORT_TEMPLATES, before);
});

test("loadCustomTemplatesV2 : un fichier V2 complet est conservé et isolé des données source", async () => {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  const resources = new TFolder("Projet/Resources");
  const layouts = new TFolder("Projet/Resources/Layouts");
  const custom = new TFile("Projet/Resources/Layouts/complet.md");
  manuscript.parent = project; resources.parent = project; layouts.parent = resources; custom.parent = layouts;
  project.children = [manuscript, resources]; resources.children = [layouts]; layouts.children = [custom];
  const frontmatter = {
    version: 2, profile: "document", page: { size: "A5", orientation: "portrait", marginsCm: { top: 1, bottom: 1, left: 1, right: 1 }, mirrorMargins: false, columns: { count: 1, gutterPt: 0 } },
    body: { fontFamily: "Georgia", fontSizePt: 11, lineHeight: 1.5, align: "left", firstLineIndentPt: 0, paragraphSpacingBeforePt: 0, paragraphSpacingAfterPt: 0, hyphenation: false },
    headings: { h1: {}, h2: {}, h3: {}, h4: {}, h5: {}, h6: {} }, blockquote: {}, sceneDivider: "",
    header: { enabled: true, left: "L", center: "", right: "R", distanceCm: 1, bodyGapPt: 2, differentOddEven: false },
    footer: { enabled: true, left: "", center: "", right: "F", distanceCm: 1, bodyGapPt: 2 },
    firstPage: { hideHeader: true, pageNumberPosition: "right" }, titlePage: { styles: { titre: { fontSizePt: 22 } } },
  };
  const before = structuredClone(frontmatter);
  const { vault, fileManager } = createFakeVault([project, manuscript, resources, layouts, custom]);
  const app = { vault, fileManager, metadataCache: { getFileCache: () => ({ frontmatter }) } };

  const templates = await loadCustomTemplatesV2(app, { projectFolder: manuscript.path });
  templates.complet.body.fontSizePt = 99;
  templates.complet.titlePage.styles.titre.fontSizePt = 9;

  assert.equal(templates.complet.profile, "document");
  assert.equal(templates.complet.page.size, "A5");
  assert.equal(templates.complet.header.left, "L");
  assert.deepEqual(frontmatter, before);
});

test("duplicateExportTemplate : aucun dossier projet -> null, sans lever", async () => {
  const { vault, fileManager } = createFakeVault([]);
  const app = { vault, fileManager, metadataCache: { getFileCache: () => ({ frontmatter: {} }) } };
  const settings = { projectFolder: "Inexistant", exportTemplate: "classique" };

  const result = await duplicateExportTemplate(app, settings);

  assert.equal(result, null);
});

test("gabarit personnalisé : le renommage ne change que le label, jamais la clé ni les propriétés V2", async () => {
  const project = new TFolder("Projet"); const manuscript = new TFolder("Projet/Manuscrit"); const resources = new TFolder("Projet/Resources"); const layouts = new TFolder("Projet/Resources/Layouts"); const custom = new TFile("Projet/Resources/Layouts/perso.md");
  manuscript.parent = project; resources.parent = project; layouts.parent = resources; custom.parent = layouts;
  project.children = [manuscript, resources]; resources.children = [layouts]; layouts.children = [custom];
  const { vault, fileManager } = createFakeVault([project, manuscript, resources, layouts, custom]);
  const original = { version: 2, label: "Avant", page: { size: "A4" }, body: { fontFamily: "Georgia" }, headings: { h1: { fontSizePt: 24 } } };
  let saved;
  fileManager.processFrontMatter = async (_file, update) => { saved = JSON.parse(JSON.stringify(original)); update(saved); };
  const app = { vault, fileManager, metadataCache: { getFileCache: () => ({ frontmatter: original }) } };
  const settings = { projectFolder: manuscript.path, exportTemplate: "perso" };

  assert.equal(customTemplateFile(app, settings, "perso"), custom);
  assert.equal(await renameCustomTemplate(app, settings, "perso", "Après"), true);
  assert.equal(saved.label, "Après");
  assert.deepEqual({ ...saved, label: "Avant" }, original);
  assert.equal(custom.basename, "perso");
  assert.equal(custom.path, "Projet/Resources/Layouts/perso.md");
  assert.equal(settings.exportTemplate, "perso");
});

test("gabarit personnalisé : la suppression envoie un gabarit pur à la corbeille et revient à Classique", async () => {
  const project = new TFolder("Projet"); const manuscript = new TFolder("Projet/Manuscrit"); const resources = new TFolder("Projet/Resources"); const layouts = new TFolder("Projet/Resources/Layouts"); const custom = new TFile("Projet/Resources/Layouts/perso.md");
  manuscript.parent = project; resources.parent = project; layouts.parent = resources; custom.parent = layouts;
  project.children = [manuscript, resources]; resources.children = [layouts]; layouts.children = [custom];
  const { vault, fileManager } = createFakeVault([project, manuscript, resources, layouts, custom]);
  const settings = { projectFolder: manuscript.path, exportTemplate: "perso" };
  const result = await deleteCustomTemplate({ vault, fileManager }, settings, "perso");
  assert.deepEqual(result, { deleted: true, activeChanged: true });
  assert.equal(vault.getAbstractFileByPath(custom.path), null);
  assert.equal(settings.exportTemplate, "classique");
});

test("gabarit intégré : sans fichier custom, ni renommage ni suppression ne sont possibles ; un override supprimé révèle l'intégré", async () => {
  const project = new TFolder("Projet"); const manuscript = new TFolder("Projet/Manuscrit"); const resources = new TFolder("Projet/Resources"); const layouts = new TFolder("Projet/Resources/Layouts"); const custom = new TFile("Projet/Resources/Layouts/classique.md");
  manuscript.parent = project; resources.parent = project; layouts.parent = resources; custom.parent = layouts;
  project.children = [manuscript, resources]; resources.children = [layouts]; layouts.children = [custom];
  const { vault, fileManager } = createFakeVault([project, manuscript, resources, layouts, custom]);
  const app = { vault, fileManager, metadataCache: { getFileCache: (file) => ({ frontmatter: file === custom ? { label: "Classique maison", fontSizePt: 13 } : {} }) } };
  const settings = { projectFolder: manuscript.path, exportTemplate: "classique" };

  assert.equal(await renameCustomTemplate(app, settings, "apa", "Interdit"), false);
  assert.deepEqual(await deleteCustomTemplate(app, settings, "apa"), { deleted: false, activeChanged: false });
  assert.deepEqual(await deleteCustomTemplate(app, settings, "classique"), { deleted: true, activeChanged: false });
  assert.equal(settings.exportTemplate, "classique");
  assert.equal((await resolveExportTemplate(app, settings, "classique")).label, EXPORT_TEMPLATES.classique.label);
});

test("listExportTemplates : catalogue proposé, historiques actifs et personnalisés gardent leur visibilité et leur priorité", async () => {
  const project = new TFolder("Projet"); const manuscript = new TFolder("Projet/Manuscrit"); const resources = new TFolder("Projet/Resources"); const layouts = new TFolder("Projet/Resources/Layouts");
  const customApa = new TFile("Projet/Resources/Layouts/apa.md"); const ulysses = new TFile("Projet/Resources/Layouts/ulysses.md"); const word = new TFile("Projet/Resources/Layouts/word.md");
  manuscript.parent = project; resources.parent = project; layouts.parent = resources; customApa.parent = layouts; ulysses.parent = layouts; word.parent = layouts;
  project.children = [manuscript, resources]; resources.children = [layouts]; layouts.children = [customApa, ulysses, word];
  const { vault, fileManager } = createFakeVault([project, manuscript, resources, layouts, customApa, ulysses, word]);
  const app = { vault, fileManager, metadataCache: { getFileCache: (file) => ({ frontmatter: file === customApa ? { label: "APA maison", fontSizePt: 13 } : file === ulysses ? { label: "Import Ulysses", fontSizePt: 11 } : file === word ? { label: "Import Word", fontSizePt: 11 } : {} }) } };
  const settings = { projectFolder: manuscript.path, exportTemplate: "classique" };

  const fresh = await listExportTemplates(app, settings);
  assert.deepEqual(fresh.map((tpl) => tpl.key), ["classique", "romanSimple", "moderne", "apa", "these", "ulysses", "word"]);
  assert.equal(fresh.find((tpl) => tpl.key === "apa").label, "APA maison");
  assert.equal(fresh.some((tpl) => tpl.key === "tapuscrit"), false);
  assert.equal(fresh.some((tpl) => tpl.key === "romanFrancais"), false);

  settings.exportTemplate = "tapuscrit";
  assert.ok((await listExportTemplates(app, settings)).some((tpl) => tpl.key === "tapuscrit"));
  settings.exportTemplate = "romanFrancais";
  assert.ok((await listExportTemplates(app, settings)).some((tpl) => tpl.key === "romanFrancais"));
  assert.equal((await resolveExportTemplate(app, settings, "tapuscrit")).key, "tapuscrit");
  assert.equal((await resolveExportTemplateV2(app, settings, "romanFrancais")).body.fontFamily, EXPORT_TEMPLATES.romanFrancais.fontFamily);
});

test("exportBuiltInTemplates : ne matérialise que les cinq gabarits proposés dans Mises en page", async () => {
  const project = new TFolder("Projet"); const manuscript = new TFolder("Projet/Manuscrit"); manuscript.parent = project; project.children = [manuscript];
  const { vault, fileManager } = createFakeVault([project, manuscript]);
  const app = { vault, fileManager, metadataCache: { getFileCache: () => ({ frontmatter: {} }) } };
  const count = await exportBuiltInTemplates(app, { projectFolder: manuscript.path });
  assert.equal(count, 5);
  for (const key of ["classique", "romanSimple", "moderne", "apa", "these"]) assert.ok(vault.getAbstractFileByPath(`Projet/_Feuillets/Ressources/Mises en page/${key}.md`));
  assert.equal(vault.getAbstractFileByPath("Projet/_Feuillets/Ressources/Mises en page/tapuscrit.md"), null);
  assert.equal(vault.getAbstractFileByPath("Projet/_Feuillets/Ressources/Mises en page/romanFrancais.md"), null);
  assert.equal((await ensureTemplateFile(app, { projectFolder: manuscript.path }, "tapuscrit"))?.basename, "tapuscrit");
});

test("export templates custom : un fichier placé dans Ressources/Modèles n'est PAS reconnu comme mise en page", async () => {
  const project = new TFolder("Projet");
  const manuscript = new TFolder("Projet/Manuscrit");
  const resources = new TFolder("Projet/_Feuillets/Ressources");
  const modeles = new TFolder("Projet/_Feuillets/Ressources/Modèles");
  const fakeLayout = new TFile("Projet/_Feuillets/Ressources/Modèles/fake.md");
  manuscript.parent = project; resources.parent = project; modeles.parent = resources; fakeLayout.parent = modeles;
  project.children = [manuscript, resources]; resources.children = [modeles]; modeles.children = [fakeLayout];
  const { vault, fileManager } = createFakeVault([project, manuscript, resources, modeles, fakeLayout]);
  const app = { vault, fileManager, metadataCache: { getFileCache: () => ({ frontmatter: { label: "Fake Layout" } }) } };
  const settings = { projectFolder: manuscript.path };

  const templates = await loadCustomTemplates(app, settings);
  assert.equal(templates.fake, undefined, "Modèles ne doit pas servir de dossier de mises en page");
});
